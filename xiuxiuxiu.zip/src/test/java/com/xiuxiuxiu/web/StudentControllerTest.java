package com.xiuxiuxiu.web;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
public class StudentControllerTest {

	@Test
	public void testIndex() {
		fail("尚未实现");
	}

	@Test
	public void testHome() {
		fail("尚未实现");
	}

	@Test
	public void testEdit() {
		fail("尚未实现");
	}

	@Test
	public void testDelete() {
		fail("尚未实现");
	}

	@Test
	public void testLogin() {
		fail("尚未实现");
	}

	@Test
	public void testRegister() {
		fail("尚未实现");
	}

	@Test
	public void testExit() {
		fail("尚未实现");
	}

	@Test
	public void testEquipmentEdit() {
		fail("尚未实现");
	}

	@Test
	public void testEquipmentDelete() {
		fail("尚未实现");
	}

	@Test
	public void testAddEquipment() {
		fail("尚未实现");
	}

	@Test
	public void testIsMobileNO() {
		fail("尚未实现");
	}

	@Test
	public void testIsEmail() {
		fail("尚未实现");
	}

}
