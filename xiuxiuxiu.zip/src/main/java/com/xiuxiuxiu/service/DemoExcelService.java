package com.xiuxiuxiu.service;

import java.util.List;

import com.xiuxiuxiu.model.DemoExcel;

public interface DemoExcelService {
	public List<DemoExcel> getDemoExcelList();
}
